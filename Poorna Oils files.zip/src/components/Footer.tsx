import { Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';

export function Footer() {
  return (
    <footer className="bg-green-800 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <span className="text-xl"></span>
              <span className="text-xl">Poorna</span>
            </div>
            <p className="text-green-100">
              Premium quality cooking oils for health-conscious families. 
              Experience the difference of pure, natural flavors.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="text-green-100 hover:text-white hover:bg-green-700">
                <Facebook className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-green-100 hover:text-white hover:bg-green-700">
                <Twitter className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-green-100 hover:text-white hover:bg-green-700">
                <Instagram className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-lg">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#home" className="text-green-100 hover:text-white transition-colors">Home</a></li>
              <li><a href="#about" className="text-green-100 hover:text-white transition-colors">About Us</a></li>
              <li><a href="#products" className="text-green-100 hover:text-white transition-colors">Products</a></li>
              <li><a href="#contact" className="text-green-100 hover:text-white transition-colors">Contact</a></li>
              <li><a href="#" className="text-green-100 hover:text-white transition-colors">FAQ</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="text-lg">Contact Info</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-green-300" />
                <span className="text-green-100">+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-green-300" />
                <span className="text-green-100">info@poornaoil.com</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-green-300" />
                <span className="text-green-100">123 Oil Street, City, State 12345</span>
              </div>
            </div>
          </div>

          {/* Newsletter */}
          <div className="space-y-4">
            <h3 className="text-lg">Newsletter</h3>
            <p className="text-green-100">
              Subscribe to get updates on new products and special offers.
            </p>
            <div className="space-y-2">
              <Input 
                placeholder="Enter your email"
                className="bg-green-700 border-green-600 text-white placeholder:text-green-200"
              />
              <Button className="w-full bg-yellow-400 hover:bg-yellow-500 text-black">
                Subscribe
              </Button>
            </div>
          </div>
        </div>

        <div className="border-t border-green-700 mt-8 pt-8 text-center">
          <p className="text-green-100">
            © 2025 Poorna Oil. All rights reserved. | Privacy Policy | Terms of Service
          </p>
        </div>
      </div>
    </footer>
  );
}