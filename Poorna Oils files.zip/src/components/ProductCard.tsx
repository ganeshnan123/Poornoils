import { ShoppingCart, Star, Lock } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

export interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  rating: number;
  reviews: number;
  description: string;
  category: string;
}

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  isLoggedIn?: boolean;
}

export function ProductCard({ product, onAddToCart, isLoggedIn = true }: ProductCardProps) {
  const discount = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <Card className="group hover:shadow-xl transition-all duration-300 overflow-hidden border-0 shadow-lg hover:scale-105">
      <div className="relative">
        <ImageWithFallback
          src={product.image}
          alt={product.name}
          className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
        />
        
        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        
        {discount > 0 && (
          <Badge className="absolute top-3 left-3 bg-red-500 hover:bg-red-600 text-white shadow-lg">
            -{discount}%
          </Badge>
        )}
        
        <Badge 
          variant="secondary" 
          className="absolute top-3 right-3 bg-green-100 text-green-800 hover:bg-green-200 shadow-lg"
        >
          {product.category}
        </Badge>

        {/* Quick view overlay */}
        <div className="absolute inset-0 bg-green-900/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <Button
            variant="secondary"
            className="bg-white text-green-800 hover:bg-green-50 shadow-lg transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300"
          >
            Quick View
          </Button>
        </div>
      </div>
      
      <CardContent className="p-5 space-y-4 bg-gradient-to-b from-white to-green-50/50">
        <div className="flex items-center space-x-1">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`h-4 w-4 ${
                i < Math.floor(product.rating)
                  ? 'fill-yellow-400 text-yellow-400'
                  : 'text-gray-300'
              }`}
            />
          ))}
          <span className="text-sm text-green-600 ml-2 font-medium">
            {product.rating} ({product.reviews})
          </span>
        </div>
        
        <h3 className="text-lg text-green-800 font-semibold group-hover:text-green-900 transition-colors">
          {product.name}
        </h3>
        
        <p className="text-sm text-green-600 line-clamp-2 leading-relaxed">
          {product.description}
        </p>
        
        <div className="flex items-center justify-between pt-2">
          <div className="space-x-2">
            <span className="text-xl font-bold text-green-700">₹{product.price}</span>
            {product.originalPrice && (
              <span className="text-sm text-gray-500 line-through">
                ₹{product.originalPrice}
              </span>
            )}
          </div>
          
          <Button
            onClick={() => onAddToCart(product)}
            className={`${
              isLoggedIn 
                ? 'bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white'
                : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
            } shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105`}
            size="sm"
          >
            {isLoggedIn ? (
              <>
                <ShoppingCart className="h-4 w-4 mr-2" />
                Add to Cart
              </>
            ) : (
              <>
                <Lock className="h-4 w-4 mr-2" />
                Sign In to Buy
              </>
            )}
          </Button>
        </div>

        {!isLoggedIn && (
          <div className="text-center pt-2">
            <p className="text-xs text-amber-600 font-medium">
              🔒 Login required to purchase
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}