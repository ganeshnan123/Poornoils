import { ShoppingCart, User, LogOut, Settings, Package } from 'lucide-react';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

interface User {
  name: string;
  email: string;
}

interface HeaderProps {
  cartItemsCount: number;
  onCartClick: () => void;
  isLoggedIn: boolean;
  user: User | null;
  onLogin: () => void;
  onLogout: () => void;
}

export function Header({ 
  cartItemsCount, 
  onCartClick, 
  isLoggedIn, 
  user, 
  onLogin, 
  onLogout 
}: HeaderProps) {
  return (
    <header className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-emerald-700 text-white relative overflow-hidden shadow-lg">
      {/* Decorative wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-8 fill-emerald-600">
          <path d="M0,96L48,80C96,64,192,32,288,37.3C384,43,480,85,576,90.7C672,96,768,64,864,58.7C960,53,1056,75,1152,80L1200,85.3L1200,120L1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z"></path>
        </svg>
      </div>
      
      <nav className="container mx-auto px-4 py-4 flex items-center justify-between relative z-10">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-amber-400 rounded-full flex items-center justify-center shadow-lg">
            <span className="text-xl">🌱</span>
          </div>
          <div>
            <h1 className="text-xl font-bold">Poorna Oils</h1>
            <p className="text-xs text-emerald-100">Pure Oils for a Healthy Life</p>
          </div>
        </div>
        
        <div className="hidden md:flex space-x-6">
          <a href="#home" className="hover:text-amber-300 transition-colors relative group">
            Home
            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-amber-300 transition-all group-hover:w-full"></span>
          </a>
          <a href="#about" className="hover:text-amber-300 transition-colors relative group">
            About
            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-amber-300 transition-all group-hover:w-full"></span>
          </a>
          <a href="#products" className="hover:text-amber-300 transition-colors relative group">
            Products
            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-amber-300 transition-all group-hover:w-full"></span>
          </a>
          <a href="#testimonials" className="hover:text-amber-300 transition-colors relative group">
            Reviews
            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-amber-300 transition-all group-hover:w-full"></span>
          </a>
          <a href="#contact" className="hover:text-amber-300 transition-colors relative group">
            Contact
            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-amber-300 transition-all group-hover:w-full"></span>
          </a>
        </div>
        
        <div className="flex items-center space-x-4">
          {isLoggedIn && user ? (
            <>
              <Button
                variant="ghost"
                size="icon"
                onClick={onCartClick}
                className="text-white hover:text-amber-300 hover:bg-emerald-600 relative"
              >
                <ShoppingCart className="h-5 w-5" />
                {cartItemsCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {cartItemsCount}
                  </span>
                )}
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="ghost" 
                    className="flex items-center space-x-2 text-white hover:text-amber-300 hover:bg-emerald-600"
                  >
                    <div className="w-8 h-8 bg-amber-400 rounded-full flex items-center justify-center text-emerald-800 font-bold">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                    <span className="hidden md:block">{user.name}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user.name}</p>
                      <p className="text-xs leading-none text-muted-foreground">
                        {user.email}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Package className="mr-2 h-4 w-4" />
                    <span>My Orders</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <Button 
              onClick={onLogin}
              className="bg-amber-400 hover:bg-amber-500 text-emerald-800 font-medium shadow-lg"
            >
              Sign In
            </Button>
          )}
        </div>
      </nav>
    </header>
  );
}