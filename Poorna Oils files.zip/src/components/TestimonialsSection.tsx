import { Star, Quote } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Testimonial {
  id: number;
  name: string;
  location: string;
  rating: number;
  comment: string;
  avatar?: string;
  product: string;
}

export function TestimonialsSection() {
  const testimonials: Testimonial[] = [
    {
      id: 1,
      name: "Priya Sharma",
      location: "Mumbai, Maharashtra",
      rating: 5,
      comment: "The coconut oil from Poorna is absolutely pure! I've been using it for cooking and hair care for 6 months now. The quality is exceptional and you can taste the difference.",
      product: "Coconut Oil"
    },
    {
      id: 2,
      name: "Rajesh Kumar",
      location: "Delhi, NCR",
      rating: 5,
      comment: "Finally found genuine mustard oil! The traditional kachi ghani process really makes a difference. My wife loves cooking with it, and it brings back childhood flavors.",
      product: "Mustard Oil"
    },
    {
      id: 3,
      name: "Anita Patel",
      location: "Ahmedabad, Gujarat",
      rating: 4,
      comment: "Great quality groundnut oil. Perfect for deep frying and everyday cooking. The cold-pressed method preserves all the nutrients. Highly recommended!",
      product: "Groundnut Oil"
    },
    {
      id: 4,
      name: "Dr. Meera Nair",
      location: "Kochi, Kerala",
      rating: 5,
      comment: "As a nutritionist, I appreciate the purity of Poorna oils. The sesame oil is particularly good - rich in antioxidants and perfect for traditional cooking.",
      product: "Sesame Oil"
    },
    {
      id: 5,
      name: "Vikram Singh",
      location: "Jaipur, Rajasthan",
      rating: 5,
      comment: "The olive oil quality is restaurant-grade! I use it for my Italian dishes and salads. The packaging is also very professional. Will definitely reorder.",
      product: "Olive Oil"
    },
    {
      id: 6,
      name: "Lakshmi Reddy",
      location: "Hyderabad, Telangana",
      rating: 4,
      comment: "Ordered multiple oils during the festive season. The delivery was prompt and packaging was excellent. The sunflower oil is my family's favorite now.",
      product: "Sunflower Oil"
    }
  ];

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getAvatarColor = (name: string) => {
    const colors = [
      'bg-green-100 text-green-700',
      'bg-yellow-100 text-yellow-700',
      'bg-amber-100 text-amber-700',
      'bg-emerald-100 text-emerald-700',
      'bg-lime-100 text-lime-700',
      'bg-teal-100 text-teal-700'
    ];
    return colors[name.length % colors.length];
  };

  return (
    <section id="testimonials" className="py-16 bg-gradient-to-b from-green-50 to-amber-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Quote className="h-6 w-6 text-green-600" />
            <span className="text-green-600 font-medium">Customer Reviews</span>
          </div>
          <h2 className="text-4xl text-green-800 mb-4">What Our Customers Say</h2>
          <p className="text-green-600 text-lg max-w-2xl mx-auto">
            Real reviews from real customers who trust Poorna Oils for their daily cooking needs.
          </p>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
          <div className="text-center">
            <div className="text-3xl font-bold text-green-700 mb-2">5000+</div>
            <p className="text-green-600">Happy Customers</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-yellow-600 mb-2">4.8★</div>
            <p className="text-green-600">Average Rating</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-amber-600 mb-2">12+</div>
            <p className="text-green-600">Oil Varieties</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-emerald-600 mb-2">100%</div>
            <p className="text-green-600">Pure & Natural</p>
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6 space-y-4">
                {/* Rating */}
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < testimonial.rating
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>

                {/* Comment */}
                <div className="relative">
                  <Quote className="absolute -top-2 -left-2 h-8 w-8 text-green-200 z-0" />
                  <p className="text-green-700 relative z-10 italic leading-relaxed">
                    "{testimonial.comment}"
                  </p>
                </div>

                {/* Product */}
                <div className="bg-green-50 px-3 py-1 rounded-full inline-block">
                  <span className="text-xs text-green-700 font-medium">
                    Verified purchase: {testimonial.product}
                  </span>
                </div>

                {/* Customer Info */}
                <div className="flex items-center space-x-3 pt-2">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className={getAvatarColor(testimonial.name)}>
                      {getInitials(testimonial.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold text-green-800">{testimonial.name}</p>
                    <p className="text-sm text-green-600">{testimonial.location}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to action */}
        <div className="text-center mt-12">
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg">
            <h3 className="text-2xl text-green-800 mb-4">Join Thousands of Satisfied Customers</h3>
            <p className="text-green-600 mb-6">
              Experience the Poorna difference with our premium, cold-pressed oils
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <div className="flex items-center space-x-2 text-green-700">
                <span className="text-2xl">✓</span>
                <span>100% Pure & Natural</span>
              </div>
              <div className="flex items-center space-x-2 text-green-700">
                <span className="text-2xl">✓</span>
                <span>Cold-Pressed Quality</span>
              </div>
              <div className="flex items-center space-x-2 text-green-700">
                <span className="text-2xl">✓</span>
                <span>Free Home Delivery</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}