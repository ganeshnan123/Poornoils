import { useState } from 'react';
import { ProductCard, Product } from './ProductCard';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Search, Filter, Leaf } from 'lucide-react';

interface ProductCatalogProps {
  onAddToCart: (product: Product) => void;
  isLoggedIn: boolean;
  onLogin: () => void;
}

export function ProductCatalog({ onAddToCart, isLoggedIn, onLogin }: ProductCatalogProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('name');

  const products: Product[] = [
    {
      id: 1,
      name: "Premium Coconut Oil",
      price: 299,
      originalPrice: 349,
      image: "https://images.unsplash.com/photo-1582362731452-00153041a324?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2NvbnV0JTIwb2lsJTIwY29va2luZyUyMGhlYWx0aHl8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.8,
      reviews: 234,
      description: "Virgin coconut oil, cold-pressed from fresh coconuts. Rich in MCTs and perfect for cooking and hair care.",
      category: "Coconut Oil"
    },
    {
      id: 2,
      name: "Cold-Pressed Groundnut Oil",
      price: 189,
      originalPrice: 219,
      image: "https://images.unsplash.com/photo-1634045793583-176ea8dc055b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncm91bmRudXQlMjBwZWFudXQlMjBvaWwlMjBjb29raW5nfGVufDF8fHx8MTc1NTg0MTMxOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.6,
      reviews: 189,
      description: "Pure groundnut (peanut) oil extracted using traditional methods. High smoke point, ideal for deep frying.",
      category: "Groundnut Oil"
    },
    {
      id: 3,
      name: "Organic Sesame Oil",
      price: 259,
      image: "https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.7,
      reviews: 156,
      description: "Aromatic sesame oil, perfect for tempering and adding authentic flavor to traditional Indian dishes.",
      category: "Sesame Oil"
    },
    {
      id: 4,
      name: "Premium Sunflower Oil",
      price: 179,
      originalPrice: 199,
      image: "https://images.unsplash.com/photo-1684853807644-428f89ce35fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW5mbG93ZXIlMjBvaWwlMjBib3R0bGUlMjBraXRjaGVufGVufDF8fHx8MTc1NTYwMzY0NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.5,
      reviews: 201,
      description: "Light and versatile sunflower oil. Rich in Vitamin E, perfect for everyday cooking and baking.",
      category: "Sunflower Oil"
    },
    {
      id: 5,
      name: "Pure Mustard Oil",
      price: 229,
      originalPrice: 269,
      image: "https://images.unsplash.com/photo-1711374489633-1f3659ebe757?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXN0YXJkJTIwb2lsJTIwYm90dGxlJTIwZ29sZGVufGVufDF8fHx8MTc1NTg0MTMxMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.9,
      reviews: 178,
      description: "Kachi Ghani mustard oil with its distinctive pungent flavor. Traditional favorite for Bengali cuisine.",
      category: "Mustard Oil"
    },
    {
      id: 6,
      name: "Extra Virgin Olive Oil",
      price: 449,
      originalPrice: 499,
      image: "https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.8,
      reviews: 267,
      description: "Premium extra virgin olive oil from Mediterranean olives. Perfect for salads and low-heat cooking.",
      category: "Olive Oil"
    },
    {
      id: 7,
      name: "Rice Bran Oil",
      price: 199,
      image: "https://images.unsplash.com/photo-1648788767168-aa2df5105037?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyaWNlJTIwYnJhbiUyMG9pbCUyMGhlYWx0aHklMjBjb29raW5nfGVufDF8fHx8MTc1NTg0MTMyMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.4,
      reviews: 123,
      description: "Heart-healthy rice bran oil with natural antioxidants. High smoke point, ideal for all cooking methods.",
      category: "Rice Bran Oil"
    },
    {
      id: 8,
      name: "Premium Avocado Oil",
      price: 599,
      originalPrice: 649,
      image: "https://images.unsplash.com/photo-1610109790326-9a21dfe969b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb29raW5nJTIwb2lsJTIwYm90dGxlcyUyMHZhcmlldHl8ZW58MXx8fHwxNzU1NjAzNjQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.9,
      reviews: 98,
      description: "Luxury avocado oil rich in monounsaturated fats. Perfect for high-heat cooking and grilling.",
      category: "Avocado Oil"
    },
    {
      id: 9,
      name: "Cold-Pressed Flaxseed Oil",
      price: 399,
      image: "https://images.unsplash.com/photo-1582362731452-00153041a324?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2NvbnV0JTIwb2lsJTIwY29va2luZyUyMGhlYWx0aHl8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.6,
      reviews: 87,
      description: "Omega-3 rich flaxseed oil. Perfect supplement for salads and smoothies. Not for heating.",
      category: "Flaxseed Oil"
    },
    {
      id: 10,
      name: "Organic Castor Oil",
      price: 179,
      image: "https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.3,
      reviews: 145,
      description: "Pure castor oil for hair and skin care. Natural moisturizer with therapeutic properties.",
      category: "Castor Oil"
    },
    {
      id: 11,
      name: "Premium Almond Oil",
      price: 549,
      originalPrice: 599,
      image: "https://images.unsplash.com/photo-1610109790326-9a21dfe969b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb29raW5nJTIwb2lsJTIwYm90dGxlcyUyMHZhcmlldHl8ZW58MXx8fHwxNzU1NjAzNjQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.7,
      reviews: 76,
      description: "Sweet almond oil for cooking and cosmetic use. Rich in Vitamin E and healthy fats.",
      category: "Almond Oil"
    },
    {
      id: 12,
      name: "Black Sesame Oil",
      price: 329,
      image: "https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.8,
      reviews: 92,
      description: "Traditional black sesame oil with intense flavor. Ideal for Ayurvedic cooking and oil pulling.",
      category: "Sesame Oil"
    }
  ];

  const categories = ['all', ...Array.from(new Set(products.map(p => p.category)))];

  const filteredProducts = products
    .filter(product => 
      (selectedCategory === 'all' || product.category === selectedCategory) &&
      product.name.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return a.price - b.price;
        case 'price-high':
          return b.price - a.price;
        case 'rating':
          return b.rating - a.rating;
        default:
          return a.name.localeCompare(b.name);
      }
    });

  const handleAddToCart = (product: Product) => {
    if (!isLoggedIn) {
      onLogin();
      return;
    }
    onAddToCart(product);
  };

  return (
    <section id="products" className="py-16 bg-gradient-to-b from-white to-green-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Leaf className="h-6 w-6 text-green-600" />
            <span className="text-green-600 font-medium">Product Showcase</span>
          </div>
          <h2 className="text-4xl text-green-800 mb-4">Our Premium Oil Collection</h2>
          <p className="text-green-600 text-lg max-w-3xl mx-auto">
            From traditional coconut oil to exotic avocado oil - discover our complete range of 
            cold-pressed, natural oils for every cooking need and health benefit.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8 bg-white p-6 rounded-2xl shadow-lg">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-green-400 h-4 w-4" />
            <Input
              placeholder="Search for oils..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 border-green-200 focus:border-green-400 focus:ring-green-400"
            />
          </div>
          
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full md:w-48 border-green-200 focus:border-green-400">
              <Filter className="h-4 w-4 mr-2 text-green-500" />
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map(category => (
                <SelectItem key={category} value={category}>
                  {category === 'all' ? 'All Categories' : category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-full md:w-48 border-green-200 focus:border-green-400">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Name A-Z</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={handleAddToCart}
              isLoggedIn={isLoggedIn}
            />
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="h-8 w-8 text-green-500" />
            </div>
            <p className="text-green-600 text-lg">No oils found matching your criteria.</p>
            <p className="text-green-500">Try adjusting your search or filters.</p>
          </div>
        )}

        {/* Call to action */}
        <div className="text-center mt-12">
          <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-2xl p-8 text-white">
            <h3 className="text-2xl mb-4">Can't find what you're looking for?</h3>
            <p className="mb-6 text-green-100">Contact us for custom oil blends and bulk orders</p>
            <Button 
              variant="secondary"
              className="bg-yellow-400 hover:bg-yellow-500 text-green-800 px-8 py-3"
            >
              Contact Us
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}