import { Leaf, Shield, Award, Truck, Heart, Users } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function AboutSection() {
  const benefits = [
    {
      icon: Shield,
      title: "100% Purity Guaranteed",
      description: "Every drop is tested for purity. No adulterants, no artificial preservatives - just pure, natural oil."
    },
    {
      icon: Leaf,
      title: "Cold-Pressed Process",
      description: "Traditional extraction methods that preserve nutrients, flavor, and natural goodness of the oils."
    },
    {
      icon: Heart,
      title: "Organic Sourcing",
      description: "Sourced directly from certified organic farms that follow sustainable and ethical farming practices."
    },
    {
      icon: Award,
      title: "Award-Winning Quality",
      description: "Recognized by food safety authorities and awarded for maintaining the highest quality standards."
    },
    {
      icon: Truck,
      title: "Fresh Delivery",
      description: "Farm-to-table freshness with temperature-controlled delivery to maintain oil quality."
    },
    {
      icon: Users,
      title: "Family Trusted",
      description: "Trusted by over 5000+ families across India for their daily cooking and health needs."
    }
  ];

  return (
    <section id="about" className="py-16 bg-gradient-to-b from-white via-green-50 to-amber-50">
      <div className="container mx-auto px-4">
        {/* Why Choose Poorna Oils */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Leaf className="h-6 w-6 text-green-600" />
            <span className="text-green-600 font-medium">Why Choose Us</span>
          </div>
          <h2 className="text-4xl text-green-800 mb-4">Why Choose Poorna Oils?</h2>
          <p className="text-green-600 text-lg max-w-3xl mx-auto">
            We are committed to bringing you the finest quality oils that combine traditional wisdom 
            with modern safety standards for your family's health and well-being.
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {benefits.map((benefit, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group hover:scale-105 bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6 text-center space-y-4">
                <div className="w-16 h-16 bg-gradient-to-br from-green-100 to-green-200 rounded-full flex items-center justify-center mx-auto group-hover:from-green-200 group-hover:to-green-300 transition-colors duration-300">
                  <benefit.icon className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl text-green-800 font-semibold">{benefit.title}</h3>
                <p className="text-green-600 leading-relaxed">{benefit.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* About Us Story */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Users className="h-5 w-5 text-green-600" />
                <span className="text-green-600 font-medium">Our Story</span>
              </div>
              <h2 className="text-3xl text-green-800 mb-4">About Poorna Oils</h2>
            </div>
            
            <div className="space-y-4 text-green-700 leading-relaxed">
              <p>
                Founded with a vision to bring pure, healthy oils to every Indian kitchen, 
                Poorna Oils began as a family business rooted in traditional oil extraction methods.
              </p>
              
              <p>
                Our journey started when our founder, inspired by his grandmother's teachings about 
                the importance of pure oils, decided to revive the age-old cold-pressing techniques 
                that preserve the natural goodness of oils.
              </p>
              
              <p>
                Today, we work directly with over 100 farmers across India, ensuring fair trade 
                practices while maintaining the highest quality standards. Every bottle of Poorna 
                Oil carries the promise of purity, nutrition, and the love of traditional craftsmanship.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-6 pt-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-700 mb-1">2018</div>
                <p className="text-sm text-green-600">Founded</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-700 mb-1">100+</div>
                <p className="text-sm text-green-600">Partner Farmers</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-700 mb-1">12+</div>
                <p className="text-sm text-green-600">Oil Varieties</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-700 mb-1">5000+</div>
                <p className="text-sm text-green-600">Happy Families</p>
              </div>
            </div>

            <Button className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-8 py-3 shadow-lg">
              Learn More About Us
            </Button>
          </div>

          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Traditional oil pressing"
                  className="w-full h-40 object-cover rounded-lg shadow-lg hover:scale-105 transition-transform duration-300"
                />
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1582362731452-00153041a324?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2NvbnV0JTIwb2lsJTIwY29va2luZyUyMGhlYWx0aHl8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Organic coconut farming"
                  className="w-full h-32 object-cover rounded-lg shadow-lg hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="space-y-4 pt-8">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1684853807644-428f89ce35fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW5mbG93ZXIlMjBvaWwlMjBib3R0bGUlMjBraXRjaGVufGVufDF8fHx8MTc1NTYwMzY0NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Quality testing laboratory"
                  className="w-full h-32 object-cover rounded-lg shadow-lg hover:scale-105 transition-transform duration-300"
                />
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1610109790326-9a21dfe969b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb29raW5nJTIwb2lsJTIwYm90dGxlcyUyMHZhcmlldHl8ZW58MXx8fHwxNzU1NjAzNjQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Premium oil collection"
                  className="w-full h-40 object-cover rounded-lg shadow-lg hover:scale-105 transition-transform duration-300"
                />
              </div>
            </div>

            {/* Decorative elements */}
            <div className="absolute -top-4 -right-4 w-12 h-12 bg-yellow-300 rounded-full opacity-60"></div>
            <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-green-300 rounded-full opacity-40"></div>
          </div>
        </div>

        {/* Contact & Support section */}
        <div id="contact" className="mt-16 bg-gradient-to-r from-green-600 to-green-700 rounded-2xl p-8 text-white">
          <div className="text-center">
            <h3 className="text-3xl font-bold mb-4">Contact & Support</h3>
            <p className="text-green-100 text-lg mb-8 max-w-2xl mx-auto">
              Have questions about our oils or need personalized recommendations? 
              Our expert team is here to help you choose the perfect oils for your needs.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="text-center">
                <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-green-800 text-xl">📞</span>
                </div>
                <h4 className="font-semibold mb-2">Call Us</h4>
                <p className="text-green-100">+91 98765 43210</p>
                <p className="text-green-100 text-sm">Mon-Sat 9AM-7PM</p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-green-800 text-xl">✉️</span>
                </div>
                <h4 className="font-semibold mb-2">Email Us</h4>
                <p className="text-green-100">support@poornaoils.com</p>
                <p className="text-green-100 text-sm">24/7 Support</p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-green-800 text-xl">💬</span>
                </div>
                <h4 className="font-semibold mb-2">Live Chat</h4>
                <p className="text-green-100">Instant Support</p>
                <p className="text-green-100 text-sm">Available Now</p>
              </div>
            </div>
            
            <Button 
              variant="secondary"
              className="bg-yellow-400 hover:bg-yellow-500 text-green-800 px-8 py-3 font-semibold shadow-lg"
            >
              Get In Touch
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}