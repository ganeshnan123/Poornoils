import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Play, Shield, Leaf, Award } from 'lucide-react';

interface HeroSectionProps {
  isLoggedIn: boolean;
  onShopNow: () => void;
}

export function HeroSection({ isLoggedIn, onShopNow }: HeroSectionProps) {
  return (
    <section id="home" className="bg-gradient-to-br from-amber-50 via-green-50 to-yellow-50 py-16 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" className="w-full h-8 fill-green-50 rotate-180">
          <path d="M0,96L48,80C96,64,192,32,288,37.3C384,43,480,85,576,90.7C672,96,768,64,864,58.7C960,53,1056,75,1152,80L1200,85.3L1200,120L1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z"></path>
        </svg>
      </div>
      
      <div className="container mx-auto px-4 pt-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-green-700">
                <Leaf className="h-5 w-5" />
                <span className="text-lg font-medium">100% Natural & Pure</span>
              </div>
              
              <h1 className="text-5xl lg:text-7xl text-green-800 leading-tight">
                Pure Oils
                <br />
                <span className="text-yellow-600">for a</span>
                <br />
                Healthy Life
              </h1>
              
              <p className="text-green-600 text-xl max-w-md leading-relaxed">
                Discover our premium collection of cold-pressed, natural oils. 
                From traditional coconut oil to exotic avocado oil - pure nutrition for your family.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={onShopNow}
                className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-8 py-4 rounded-full text-lg shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105"
              >
                {isLoggedIn ? 'Shop Now' : 'Sign In to Shop'}
                <span className="ml-2">→</span>
              </Button>
              
              <Button 
                variant="outline"
                className="px-8 py-4 rounded-full text-lg border-2 border-green-600 text-green-700 hover:bg-green-50 shadow-lg"
              >
                <Play className="mr-2 h-5 w-5" />
                Watch Story
              </Button>
            </div>

            {/* Trust indicators */}
            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Shield className="h-6 w-6 text-green-600" />
                </div>
                <p className="text-sm text-green-700 font-medium">100% Pure</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Leaf className="h-6 w-6 text-yellow-600" />
                </div>
                <p className="text-sm text-green-700 font-medium">Cold Pressed</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Award className="h-6 w-6 text-amber-600" />
                </div>
                <p className="text-sm text-green-700 font-medium">Award Winning</p>
              </div>
            </div>
          </div>
          
          <div className="relative flex justify-center">
            <div className="relative">
              {/* Main product image */}
              <div className="relative z-10">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Premium Poorna Oils collection"
                  className="w-96 h-96 object-cover rounded-2xl shadow-2xl"
                />
                
                {/* Floating badge */}
                <div className="absolute -top-4 -right-4 bg-yellow-400 text-green-800 px-4 py-2 rounded-full shadow-lg font-bold">
                  #1 Choice
                </div>
              </div>
              
              {/* Decorative elements */}
              <div className="absolute -top-6 -left-6 w-16 h-16 bg-green-200 rounded-full opacity-60 animate-pulse"></div>
              <div className="absolute -bottom-8 -right-8 w-20 h-20 bg-yellow-200 rounded-full opacity-40"></div>
              <div className="absolute top-1/2 -left-12 w-10 h-10 bg-amber-300 rounded-full opacity-50"></div>
              
              {/* Background pattern */}
              <div className="absolute inset-0 -z-10">
                <div className="w-full h-full bg-gradient-to-br from-green-100 to-yellow-100 rounded-3xl opacity-30 transform rotate-3"></div>
              </div>
            </div>
            
            {/* Floating product cards */}
            <div className="absolute top-4 -left-8 bg-white p-3 rounded-lg shadow-lg animate-float">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-xs">🥥</span>
                </div>
                <div>
                  <p className="text-xs font-medium text-green-800">Coconut Oil</p>
                  <p className="text-xs text-green-600">₹299</p>
                </div>
              </div>
            </div>
            
            <div className="absolute bottom-4 -right-8 bg-white p-3 rounded-lg shadow-lg animate-float-delayed">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                  <span className="text-xs">🌻</span>
                </div>
                <div>
                  <p className="text-xs font-medium text-green-800">Sunflower Oil</p>
                  <p className="text-xs text-green-600">₹199</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}