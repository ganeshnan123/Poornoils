// Cart state
let cart = [];

// Load cart from localStorage
function loadCart() {
    const savedCart = localStorage.getItem('poorna_oils_cart');
    if (savedCart) {
        try {
            cart = JSON.parse(savedCart);
        } catch (e) {
            cart = [];
        }
    }
    updateCartDisplay();
}

// Save cart to localStorage
function saveCart() {
    localStorage.setItem('poorna_oils_cart', JSON.stringify(cart));
}

// Add product to cart
function addToCart(productId) {
    const product = PRODUCTS.find(p => p.id === productId);
    if (!product) return;
    
    const existingItem = cart.find(item => item.id === productId);
    
    if (existingItem) {
        existingItem.quantity += 1;
        showToast(`Updated ${product.name} quantity in cart`, 'success');
    } else {
        cart.push({
            ...product,
            quantity: 1
        });
        showToast(`Added ${product.name} to cart`, 'success');
    }
    
    saveCart();
    updateCartDisplay();
}

// Remove item from cart
function removeFromCart(productId) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        showToast(`Removed ${item.name} from cart`, 'success');
    }
    
    cart = cart.filter(item => item.id !== productId);
    saveCart();
    updateCartDisplay();
}

// Update item quantity
function updateCartQuantity(productId, quantity) {
    if (quantity <= 0) {
        removeFromCart(productId);
        return;
    }
    
    const item = cart.find(item => item.id === productId);
    if (item) {
        item.quantity = quantity;
        saveCart();
        updateCartDisplay();
    }
}

// Calculate cart total
function calculateCartTotal() {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
}

// Get total cart items count
function getCartItemsCount() {
    return cart.reduce((total, item) => total + item.quantity, 0);
}

// Create cart item HTML
function createCartItemHTML(item) {
    return `
        <div class="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
            <img src="${item.image}" alt="${item.name}" class="w-16 h-16 object-cover rounded-lg" />
            <div class="flex-1">
                <h4 class="font-medium text-green-800 text-sm">${item.name}</h4>
                <p class="text-green-600 text-sm">₹${item.price}</p>
                <div class="flex items-center space-x-2 mt-2">
                    <button onclick="updateCartQuantity(${item.id}, ${item.quantity - 1})" 
                            class="w-6 h-6 rounded-full bg-green-200 hover:bg-green-300 flex items-center justify-center text-green-700 text-sm">-</button>
                    <span class="text-sm font-medium text-green-800 w-8 text-center">${item.quantity}</span>
                    <button onclick="updateCartQuantity(${item.id}, ${item.quantity + 1})" 
                            class="w-6 h-6 rounded-full bg-green-200 hover:bg-green-300 flex items-center justify-center text-green-700 text-sm">+</button>
                </div>
            </div>
            <div class="text-right">
                <p class="font-medium text-green-800 text-sm">₹${item.price * item.quantity}</p>
                <button onclick="removeFromCart(${item.id})" 
                        class="text-red-500 hover:text-red-700 text-xs mt-1">Remove</button>
            </div>
        </div>
    `;
}

// Update cart display
function updateCartDisplay() {
    // Update cart count in header
    const cartCountElement = document.getElementById('cart-count');
    const itemCount = getCartItemsCount();
    
    if (cartCountElement) {
        if (itemCount > 0) {
            cartCountElement.textContent = itemCount;
            cartCountElement.classList.remove('hidden');
        } else {
            cartCountElement.classList.add('hidden');
        }
    }
    
    // Update cart items in sidebar
    const cartItemsContainer = document.getElementById('cart-items');
    const cartTotalElement = document.getElementById('cart-total');
    
    if (cartItemsContainer) {
        if (cart.length === 0) {
            cartItemsContainer.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    <svg class="h-12 w-12 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-1.5 6M7 13l-1.5-6m0 0L4 5M7 13h10"/>
                    </svg>
                    <p>Your cart is empty</p>
                </div>
            `;
        } else {
            cartItemsContainer.innerHTML = `
                <div class="space-y-3">
                    ${cart.map(item => createCartItemHTML(item)).join('')}
                </div>
            `;
        }
    }
    
    // Update cart total
    if (cartTotalElement) {
        cartTotalElement.textContent = `₹${calculateCartTotal()}`;
    }
}

// Toggle cart sidebar
function toggleCart() {
    const cartSidebar = document.getElementById('cart-sidebar');
    const cartBackdrop = document.getElementById('cart-backdrop');
    
    if (!cartSidebar || !cartBackdrop) return;
    
    const isOpen = !cartSidebar.classList.contains('translate-x-full');
    
    if (isOpen) {
        // Close cart
        cartSidebar.classList.add('translate-x-full');
        cartBackdrop.classList.add('hidden');
        document.body.style.overflow = '';
    } else {
        // Open cart
        cartSidebar.classList.remove('translate-x-full');
        cartBackdrop.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
}

// Clear cart (for logout)
function clearCart() {
    cart = [];
    saveCart();
    updateCartDisplay();
}