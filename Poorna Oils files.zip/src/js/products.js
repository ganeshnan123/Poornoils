// Product data
const PRODUCTS = [
    {
        id: 1,
        name: "Premium Coconut Oil",
        price: 299,
        originalPrice: 349,
        image: "https://images.unsplash.com/photo-1582362731452-00153041a324?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2NvbnV0JTIwb2lsJTIwY29va2luZyUyMGhlYWx0aHl8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080",
        rating: 4.8,
        reviews: 234,
        description: "Virgin coconut oil, cold-pressed from fresh coconuts. Rich in MCTs and perfect for cooking and hair care.",
        category: "Coconut Oil"
    },
    {
        id: 2,
        name: "Cold-Pressed Groundnut Oil",
        price: 189,
        originalPrice: 219,
        image: "https://images.unsplash.com/photo-1634045793583-176ea8dc055b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncm91bmRudXQlMjBwZWFudXQlMjBvaWwlMjBjb29raW5nfGVufDF8fHx8MTc1NTg0MTMxOHww&ixlib=rb-4.1.0&q=80&w=1080",
        rating: 4.6,
        reviews: 189,
        description: "Pure groundnut (peanut) oil extracted using traditional methods. High smoke point, ideal for deep frying.",
        category: "Groundnut Oil"
    },
    {
        id: 3,
        name: "Organic Sesame Oil",
        price: 259,
        image: "https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080",
        rating: 4.7,
        reviews: 156,
        description: "Aromatic sesame oil, perfect for tempering and adding authentic flavor to traditional Indian dishes.",
        category: "Sesame Oil"
    },
    {
        id: 4,
        name: "Premium Sunflower Oil",
        price: 179,
        originalPrice: 199,
        image: "https://images.unsplash.com/photo-1684853807644-428f89ce35fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW5mbG93ZXIlMjBvaWwlMjBib3R0bGUlMjBraXRjaGVufGVufDF8fHx8MTc1NTYwMzY0NHww&ixlib=rb-4.1.0&q=80&w=1080",
        rating: 4.5,
        reviews: 201,
        description: "Light and versatile sunflower oil. Rich in Vitamin E, perfect for everyday cooking and baking.",
        category: "Sunflower Oil"
    },
    {
        id: 5,
        name: "Pure Mustard Oil",
        price: 229,
        originalPrice: 269,
        image: "https://images.unsplash.com/photo-1711374489633-1f3659ebe757?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXN0YXJkJTIwb2lsJTIwYm90dGxlJTIwZ29sZGVufGVufDF8fHx8MTc1NTg0MTMxMHww&ixlib=rb-4.1.0&q=80&w=1080",
        rating: 4.9,
        reviews: 178,
        description: "Kachi Ghani mustard oil with its distinctive pungent flavor. Traditional favorite for Bengali cuisine.",
        category: "Mustard Oil"
    },
    {
        id: 6,
        name: "Extra Virgin Olive Oil",
        price: 449,
        originalPrice: 499,
        image: "https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080",
        rating: 4.8,
        reviews: 267,
        description: "Premium extra virgin olive oil from Mediterranean olives. Perfect for salads and low-heat cooking.",
        category: "Olive Oil"
    },
    {
        id: 7,
        name: "Rice Bran Oil",
        price: 199,
        image: "https://images.unsplash.com/photo-1648788767168-aa2df5105037?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyaWNlJTIwYnJhbiUyMG9pbCUyMGhlYWx0aHklMjBjb29raW5nfGVufDF8fHx8MTc1NTg0MTMyMXww&ixlib=rb-4.1.0&q=80&w=1080",
        rating: 4.4,
        reviews: 123,
        description: "Heart-healthy rice bran oil with natural antioxidants. High smoke point, ideal for all cooking methods.",
        category: "Rice Bran Oil"
    },
    {
        id: 8,
        name: "Premium Avocado Oil",
        price: 599,
        originalPrice: 649,
        image: "https://images.unsplash.com/photo-1610109790326-9a21dfe969b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb29raW5nJTIwb2lsJTIwYm90dGxlcyUyMHZhcmlldHl8ZW58MXx8fHwxNzU1NjAzNjQ1fDA&ixlib=rb-4.1.0&q=80&w=1080",
        rating: 4.9,
        reviews: 98,
        description: "Luxury avocado oil rich in monounsaturated fats. Perfect for high-heat cooking and grilling.",
        category: "Avocado Oil"
    },
    {
        id: 9,
        name: "Cold-Pressed Flaxseed Oil",
        price: 399,
        image: "https://images.unsplash.com/photo-1582362731452-00153041a324?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2NvbnV0JTIwb2lsJTIwY29va2luZyUyMGhlYWx0aHl8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080",
        rating: 4.6,
        reviews: 87,
        description: "Omega-3 rich flaxseed oil. Perfect supplement for salads and smoothies. Not for heating.",
        category: "Flaxseed Oil"
    },
    {
        id: 10,
        name: "Organic Castor Oil",
        price: 179,
        image: "https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080",
        rating: 4.3,
        reviews: 145,
        description: "Pure castor oil for hair and skin care. Natural moisturizer with therapeutic properties.",
        category: "Castor Oil"
    },
    {
        id: 11,
        name: "Premium Almond Oil",
        price: 549,
        originalPrice: 599,
        image: "https://images.unsplash.com/photo-1610109790326-9a21dfe969b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb29raW5nJTIwb2lsJTIwYm90dGxlcyUyMHZhcmlldHl8ZW58MXx8fHwxNzU1NjAzNjQ1fDA&ixlib=rb-4.1.0&q=80&w=1080",
        rating: 4.7,
        reviews: 76,
        description: "Sweet almond oil for cooking and cosmetic use. Rich in Vitamin E and healthy fats.",
        category: "Almond Oil"
    },
    {
        id: 12,
        name: "Black Sesame Oil",
        price: 329,
        image: "https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080",
        rating: 4.8,
        reviews: 92,
        description: "Traditional black sesame oil with intense flavor. Ideal for Ayurvedic cooking and oil pulling.",
        category: "Sesame Oil"
    }
];

// Generate star rating HTML
function generateStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    let starsHtml = '';
    
    for (let i = 0; i < fullStars; i++) {
        starsHtml += '<span class="text-yellow-400">★</span>';
    }
    
    if (hasHalfStar) {
        starsHtml += '<span class="text-yellow-400">☆</span>';
    }
    
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
        starsHtml += '<span class="text-gray-300">☆</span>';
    }
    
    return starsHtml;
}

// Create product card HTML
function createProductCard(product, isLoggedIn) {
    const discount = product.originalPrice 
        ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
        : 0;

    const buttonText = isLoggedIn ? 'Add to Cart' : 'Sign In to Buy';
    const buttonIcon = isLoggedIn ? '🛒' : '🔒';
    const buttonClass = isLoggedIn 
        ? 'bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white'
        : 'bg-gray-100 hover:bg-gray-200 text-gray-600';

    return `
        <div class="product-card bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden border-0 hover:scale-105">
            <div class="relative">
                <img src="${product.image}" alt="${product.name}" class="w-full h-48 object-cover hover:scale-110 transition-transform duration-500" />
                
                <div class="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300"></div>
                
                ${discount > 0 ? `<span class="absolute top-3 left-3 bg-red-500 text-white px-2 py-1 rounded-full text-sm shadow-lg">-${discount}%</span>` : ''}
                
                <span class="absolute top-3 right-3 bg-green-100 text-green-800 px-2 py-1 rounded-full text-sm shadow-lg">${product.category}</span>
            </div>
            
            <div class="p-5 space-y-4 bg-gradient-to-b from-white to-green-50/50">
                <div class="flex items-center space-x-1">
                    ${generateStars(product.rating)}
                    <span class="text-sm text-green-600 ml-2 font-medium">${product.rating} (${product.reviews})</span>
                </div>
                
                <h3 class="text-lg text-green-800 font-semibold hover:text-green-900 transition-colors">${product.name}</h3>
                
                <p class="text-sm text-green-600 line-clamp-2 leading-relaxed">${product.description}</p>
                
                <div class="flex items-center justify-between pt-2">
                    <div class="space-x-2">
                        <span class="text-xl font-bold text-green-700">₹${product.price}</span>
                        ${product.originalPrice ? `<span class="text-sm text-gray-500 line-through">₹${product.originalPrice}</span>` : ''}
                    </div>
                    
                    <button onclick="${isLoggedIn ? `addToCart(${product.id})` : `window.location.href='login.php'`}" 
                            class="${buttonClass} px-4 py-2 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 text-sm font-medium">
                        ${buttonIcon} ${buttonText}
                    </button>
                </div>

                ${!isLoggedIn ? '<div class="text-center pt-2"><p class="text-xs text-amber-600 font-medium">🔒 Login required to purchase</p></div>' : ''}
            </div>
        </div>
    `;
}

// Render products based on filters
function renderProducts(productsToRender, isLoggedIn = false) {
    const grid = document.getElementById('products-grid');
    if (!grid) return;
    
    grid.innerHTML = '';
    
    if (productsToRender.length === 0) {
        grid.innerHTML = `
            <div class="col-span-full text-center py-12">
                <div class="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="h-8 w-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                </div>
                <p class="text-green-600 text-lg">No oils found matching your criteria.</p>
                <p class="text-green-500">Try adjusting your search or filters.</p>
            </div>
        `;
        return;
    }
    
    productsToRender.forEach(product => {
        const productElement = document.createElement('div');
        productElement.innerHTML = createProductCard(product, isLoggedIn);
        grid.appendChild(productElement.firstElementChild);
    });
}

// Filter products based on search, category, and sort
function filterProducts() {
    const searchTerm = document.getElementById('search-input')?.value.toLowerCase() || '';
    const selectedCategory = document.getElementById('category-filter')?.value || 'all';
    const sortBy = document.getElementById('sort-filter')?.value || 'name';
    
    let filteredProducts = PRODUCTS.filter(product => {
        const matchesSearch = product.name.toLowerCase().includes(searchTerm) || 
                            product.description.toLowerCase().includes(searchTerm);
        const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
        return matchesSearch && matchesCategory;
    });
    
    // Sort products
    filteredProducts.sort((a, b) => {
        switch (sortBy) {
            case 'price-low':
                return a.price - b.price;
            case 'price-high':
                return b.price - a.price;
            case 'rating':
                return b.rating - a.rating;
            default:
                return a.name.localeCompare(b.name);
        }
    });
    
    // Check if user is logged in (from PHP session)
    const userMenuElement = document.getElementById('user-menu');
    const isLoggedIn = userMenuElement !== null;
    
    renderProducts(filteredProducts, isLoggedIn);
}

// Initialize products
function initializeProducts() {
    // Check if user is logged in
    const userMenuElement = document.getElementById('user-menu');
    const isLoggedIn = userMenuElement !== null;
    
    renderProducts(PRODUCTS, isLoggedIn);
}