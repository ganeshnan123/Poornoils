// Main application initialization
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Initialize the entire application
function initializeApp() {
    // Load cart data
    loadCart();
    
    // Initialize products
    initializeProducts();
    
    // Initialize UI components
    initializeUI();
    
    // Initialize event listeners
    initializeEventListeners();
    
    // Initialize features
    initializeFeatures();
    
    console.log('Poorna Oils application initialized successfully');
}

// Initialize UI components
function initializeUI() {
    initializeSearch();
    initializeFilters();
    initializeMobileMenu();
    initializeScrollAnimations();
    initializeLazyLoading();
    initializeKeyboardNavigation();
    initializeProductInteractions();
    initializeFormValidations();
    initializeTooltips();
    initializeBackToTop();
}

// Initialize event listeners
function initializeEventListeners() {
    // Handle newsletter subscription
    handleNewsletterSubmit();
    
    // Handle window resize
    window.addEventListener('resize', debounce(handleWindowResize, 250));
    
    // Handle page visibility changes
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Handle online/offline status
    window.addEventListener('online', handleOnlineStatus);
    window.addEventListener('offline', handleOfflineStatus);
}

// Initialize additional features
function initializeFeatures() {
    // Check for saved user preferences
    loadUserPreferences();
    
    // Initialize performance monitoring
    initializePerformanceMonitoring();
    
    // Initialize analytics (if needed)
    initializeAnalytics();
}

// Handle window resize events
function handleWindowResize() {
    // Update mobile menu state
    const navigationLinks = document.querySelector('.hidden.md\\:flex');
    if (device.isDesktop() && navigationLinks) {
        navigationLinks.classList.remove('flex', 'flex-col', 'absolute', 'top-full', 'left-0', 'right-0', 'bg-green-700', 'p-4', 'space-y-2');
        navigationLinks.classList.add('hidden');
    }
    
    // Update cart sidebar if needed
    if (device.isMobile()) {
        const cartSidebar = document.getElementById('cart-sidebar');
        if (cartSidebar) {
            cartSidebar.style.width = '100%';
        }
    }
}

// Handle page visibility changes
function handleVisibilityChange() {
    if (document.hidden) {
        // Page is hidden - pause animations, etc.
        console.log('Page hidden - pausing non-essential operations');
    } else {
        // Page is visible - resume operations
        console.log('Page visible - resuming operations');
        updateCartDisplay(); // Refresh cart in case it was updated in another tab
    }
}

// Handle online status
function handleOnlineStatus() {
    showToast('You are back online!', 'success');
}

function handleOfflineStatus() {
    showToast('You are offline. Some features may not work.', 'warning');
}

// Load user preferences from localStorage
function loadUserPreferences() {
    const preferences = storage.get('user_preferences') || {};
    
    // Apply saved theme preference
    if (preferences.theme) {
        document.body.classList.toggle('dark', preferences.theme === 'dark');
    }
    
    // Apply saved filter preferences
    if (preferences.lastCategory) {
        const categoryFilter = document.getElementById('category-filter');
        if (categoryFilter) {
            categoryFilter.value = preferences.lastCategory;
        }
    }
    
    if (preferences.lastSort) {
        const sortFilter = document.getElementById('sort-filter');
        if (sortFilter) {
            sortFilter.value = preferences.lastSort;
        }
    }
}

// Save user preferences
function saveUserPreferences() {
    const categoryFilter = document.getElementById('category-filter');
    const sortFilter = document.getElementById('sort-filter');
    
    const preferences = {
        lastCategory: categoryFilter?.value || 'all',
        lastSort: sortFilter?.value || 'name',
        theme: document.body.classList.contains('dark') ? 'dark' : 'light'
    };
    
    storage.set('user_preferences', preferences);
}

// Initialize performance monitoring
function initializePerformanceMonitoring() {
    // Monitor page load performance
    window.addEventListener('load', function() {
        setTimeout(() => {
            const perfData = performance.getEntriesByType('navigation')[0];
            if (perfData) {
                console.log('Page load time:', perfData.loadEventEnd - perfData.loadEventStart, 'ms');
            }
        }, 0);
    });
    
    // Monitor resource loading
    const observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
            if (entry.duration > 1000) { // Log slow resources
                console.warn('Slow resource:', entry.name, entry.duration + 'ms');
            }
        }
    });
    
    try {
        observer.observe({ entryTypes: ['resource'] });
    } catch (e) {
        // PerformanceObserver not supported
    }
}

// Initialize analytics (placeholder)
function initializeAnalytics() {
    // This would integrate with Google Analytics, Mixpanel, etc.
    console.log('Analytics initialized');
    
    // Track page view
    trackEvent('page_view', {
        page: window.location.pathname,
        timestamp: new Date().toISOString()
    });
}

// Track events (placeholder)
function trackEvent(eventName, properties = {}) {
    // This would send to your analytics service
    console.log('Event tracked:', eventName, properties);
}

// Global error handler
window.addEventListener('error', function(e) {
    console.error('Global error:', e.error);
    showToast('Something went wrong. Please refresh the page.', 'error');
    
    // Track error
    trackEvent('error', {
        message: e.message,
        filename: e.filename,
        lineno: e.lineno,
        colno: e.colno
    });
});

// Unhandled promise rejection handler
window.addEventListener('unhandledrejection', function(e) {
    console.error('Unhandled promise rejection:', e.reason);
    showToast('An unexpected error occurred.', 'error');
    
    // Track error
    trackEvent('promise_rejection', {
        reason: e.reason?.toString() || 'Unknown reason'
    });
});

// Save preferences before page unload
window.addEventListener('beforeunload', function() {
    saveUserPreferences();
});

// Export functions for global access (if needed)
window.PoornaOils = {
    addToCart,
    removeFromCart,
    updateCartQuantity,
    toggleCart,
    filterProducts,
    showToast,
    scrollToElement,
    trackEvent
};