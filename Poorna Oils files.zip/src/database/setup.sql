-- Create database
CREATE DATABASE IF NOT EXISTS poorna_oils;
USE poorna_oils;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    original_price DECIMAL(10, 2),
    category VARCHAR(100) NOT NULL,
    image_url VARCHAR(500),
    rating DECIMAL(3, 2) DEFAULT 0,
    reviews_count INT DEFAULT 0,
    stock_quantity INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Cart table
CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_product (user_id, product_id)
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Insert sample products
INSERT INTO products (name, description, price, original_price, category, image_url, rating, reviews_count, stock_quantity) VALUES
('Premium Coconut Oil', 'Virgin coconut oil, cold-pressed from fresh coconuts. Rich in MCTs and perfect for cooking and hair care.', 299.00, 349.00, 'Coconut Oil', 'https://images.unsplash.com/photo-1582362731452-00153041a324?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2NvbnV0JTIwb2lsJTIwY29va2luZyUyMGhlYWx0aHl8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080', 4.8, 234, 50),

('Cold-Pressed Groundnut Oil', 'Pure groundnut (peanut) oil extracted using traditional methods. High smoke point, ideal for deep frying.', 189.00, 219.00, 'Groundnut Oil', 'https://images.unsplash.com/photo-1634045793583-176ea8dc055b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncm91bmRudXQlMjBwZWFudXQlMjBvaWwlMjBjb29raW5nfGVufDF8fHx8MTc1NTg0MTMxOHww&ixlib=rb-4.1.0&q=80&w=1080', 4.6, 189, 75),

('Organic Sesame Oil', 'Aromatic sesame oil, perfect for tempering and adding authentic flavor to traditional Indian dishes.', 259.00, NULL, 'Sesame Oil', 'https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080', 4.7, 156, 30),

('Premium Sunflower Oil', 'Light and versatile sunflower oil. Rich in Vitamin E, perfect for everyday cooking and baking.', 179.00, 199.00, 'Sunflower Oil', 'https://images.unsplash.com/photo-1684853807644-428f89ce35fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW5mbG93ZXIlMjBvaWwlMjBib3R0bGUlMjBraXRjaGVufGVufDF8fHx8MTc1NTYwMzY0NHww&ixlib=rb-4.1.0&q=80&w=1080', 4.5, 201, 100),

('Pure Mustard Oil', 'Kachi Ghani mustard oil with its distinctive pungent flavor. Traditional favorite for Bengali cuisine.', 229.00, 269.00, 'Mustard Oil', 'https://images.unsplash.com/photo-1711374489633-1f3659ebe757?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXN0YXJkJTIwb2lsJTIwYm90dGxlJTIwZ29sZGVufGVufDF8fHx8MTc1NTg0MTMxMHww&ixlib=rb-4.1.0&q=80&w=1080', 4.9, 178, 40),

('Extra Virgin Olive Oil', 'Premium extra virgin olive oil from Mediterranean olives. Perfect for salads and low-heat cooking.', 449.00, 499.00, 'Olive Oil', 'https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080', 4.8, 267, 60),

('Rice Bran Oil', 'Heart-healthy rice bran oil with natural antioxidants. High smoke point, ideal for all cooking methods.', 199.00, NULL, 'Rice Bran Oil', 'https://images.unsplash.com/photo-1648788767168-aa2df5105037?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyaWNlJTIwYnJhbiUyMG9pbCUyMGhlYWx0aHklMjBjb29raW5nfGVufDF8fHx8MTc1NTg0MTMyMXww&ixlib=rb-4.1.0&q=80&w=1080', 4.4, 123, 80),

('Premium Avocado Oil', 'Luxury avocado oil rich in monounsaturated fats. Perfect for high-heat cooking and grilling.', 599.00, 649.00, 'Avocado Oil', 'https://images.unsplash.com/photo-1610109790326-9a21dfe969b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb29raW5nJTIwb2lsJTIwYm90dGxlcyUyMHZhcmlldHl8ZW58MXx8fHwxNzU1NjAzNjQ1fDA&ixlib=rb-4.1.0&q=80&w=1080', 4.9, 98, 25),

('Cold-Pressed Flaxseed Oil', 'Omega-3 rich flaxseed oil. Perfect supplement for salads and smoothies. Not for heating.', 399.00, NULL, 'Flaxseed Oil', 'https://images.unsplash.com/photo-1582362731452-00153041a324?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2NvbnV0JTIwb2lsJTIwY29va2luZyUyMGhlYWx0aHl8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080', 4.6, 87, 35),

('Organic Castor Oil', 'Pure castor oil for hair and skin care. Natural moisturizer with therapeutic properties.', 179.00, NULL, 'Castor Oil', 'https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080', 4.3, 145, 45),

('Premium Almond Oil', 'Sweet almond oil for cooking and cosmetic use. Rich in Vitamin E and healthy fats.', 549.00, 599.00, 'Almond Oil', 'https://images.unsplash.com/photo-1610109790326-9a21dfe969b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb29raW5nJTIwb2lsJTIwYm90dGxlcyUyMHZhcmlldHl8ZW58MXx8fHwxNzU1NjAzNjQ1fDA&ixlib=rb-4.1.0&q=80&w=1080', 4.7, 76, 20),

('Black Sesame Oil', 'Traditional black sesame oil with intense flavor. Ideal for Ayurvedic cooking and oil pulling.', 329.00, NULL, 'Sesame Oil', 'https://images.unsplash.com/photo-1587717415723-8c89fe42c76c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGl2ZSUyMG9pbCUyMGJvdHRsZSUyMGNvb2tpbmd8ZW58MXx8fHwxNzU1NjAzNjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080', 4.8, 92, 30);