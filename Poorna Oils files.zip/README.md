
  # Poorna Oils files

  This is a code bundle for Poorna Oils files. The original project is available at https://www.figma.com/design/giSqybyYOi3RbhA0yR5kdp/Poorna-Oils-files.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  